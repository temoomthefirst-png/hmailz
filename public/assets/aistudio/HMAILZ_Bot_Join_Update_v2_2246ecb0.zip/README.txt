HMAILZ Games — Bot Join Update

Replace the existing index.html in your hmailz-game GitHub Pages repository with this index.html. Keep a backup of the old file first.

- Regular bot profiles display a BOT tag.
- HMAILZ and ChatGPT profiles have Join disabled.
- Other bot profiles' Join buttons launch the matching game locally, when that game exists in this version.
- The old multiplayer-server demo warning is removed.

Important: this is local game launching only. It does not create a shared live multiplayer session or make bots physically join the same online server.
